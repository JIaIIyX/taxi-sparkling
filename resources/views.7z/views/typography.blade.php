



@extends('..\layouts\layout')
@section('content')



    <br />
    <b>Warning</b>: include(sections/typography.php): Failed to open stream: No such file or directory in <b>E:\web-dev\angfuzsoft\html\taxiar-html\build\inc\functions.php</b> on line <b>20</b><br />
    <br />
    <b>Warning</b>: include(): Failed opening 'sections/typography.php' for inclusion (include_path='E:\web-dev\server\php\PEAR') in <b>E:\web-dev\angfuzsoft\html\taxiar-html\build\inc\functions.php</b> on line <b>20</b><br />
    @endsection