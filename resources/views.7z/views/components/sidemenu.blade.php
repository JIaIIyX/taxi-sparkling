<div class="sidemenu-wrapper d-none d-lg-block  ">
        <div class="sidemenu-content bg-title">
            <button class="closeButton sideMenuCls"><i class="far fa-times"></i></button>
            <div class="widget footer-widget">
                <h3 class="widget_title">About Company</h3>
                <div class="th-widget-about">
                    <p class="footer-text">Centric aplications productize before front end vortals visualize front end is results and value added</p>
                    <h4 class="footer-info-title">WE ARE AVAILABLE</h4>
                    <p class="footer-text">Mon-Sat: 09.00 am to 6.30 pm</p>
                    <a href="contact.html" class="th-btn style3"><span class="btn-text">Contact Us</span></a>
                </div>
            </div>
            <div class="widget footer-widget">
                <h3 class="widget_title">Recent Posts</h3>
                <div class="recent-post-wrap">
                    <div class="recent-post">
                        <div class="media-img">
                            <a href="blog-details.html"><img src="assets/img/blog/recent-post-1-2.jpg" alt="Blog Image"></a>
                        </div>
                        <div class="media-body">
                            <div class="recent-post-meta">
                                <a href="blog.html"><i class="far fa-calendar-days"></i>22th May, 2024</a>
                            </div>
                            <h4 class="post-title"><a class="text-inherit" href="blog-details.html">How To Start Car Engine Faster</a></h4>
                            <a class="line-btn" href="blog.html">Read More<i class="fa-regular fa-arrow-right"></i></a>
                        </div>
                    </div>
                    <div class="recent-post">
                        <div class="media-img">
                            <a href="blog-details.html"><img src="assets/img/blog/recent-post-1-3.jpg" alt="Blog Image"></a>
                        </div>
                        <div class="media-body">
                            <div class="recent-post-meta">
                                <a href="blog.html"><i class="far fa-calendar-days"></i>25th May, 2024</a>
                            </div>
                            <h4 class="post-title"><a class="text-inherit" href="blog-details.html">How to start car engine slowly</a></h4>
                            <a class="line-btn" href="blog.html">Read More<i class="fa-regular fa-arrow-right"></i></a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="widget footer-widget">
                <h4 class="widget_title">Get Newsletter</h4>
                <div class="newsletter-widget">
                    <p class="md-20">Sign up today for hints, tips & latest car overview and news</p>
                    <form class="newsletter-form">
                        <input class="form-control" type="email" placeholder="Email Address" required="">
                        <button type="submit" class="newsletter-btn"><i class="fas fa-envelope"></i></button>
                    </form>
                    <div class="th-social  style2">
                        <a target="_blank" href="https://facebook.com/"><i class="fab fa-facebook-f"></i></a>
                        <a target="_blank" href="https://twitter.com/"><i class="fab fa-twitter"></i></a>
                        <a target="_blank" href="https://instagram.com/"><i class="fab fa-instagram"></i></a>
                        <a target="_blank" href="https://linkedin.com/"><i class="fab fa-linkedin-in"></i></a>
                    </div>
                </div>
            </div>
        </div>
    </div>