<footer class="footer-wrapper footer-layout1">
        <div class="widget-area">
            <div class="container">
                <div class="row justify-content-between">
                    <div class="col-md-6 col-xl-3">
                        <div class="widget footer-widget">
                            <h3 class="widget_title">About Company</h3>
                            <div class="th-widget-about">
                                <p class="footer-text">Centric aplications productize front end vortals visualize front end isite results and value added globally for simplify alternative systems without cross-platform models.</p>
                                <div class="th-social  style2">
                                    <a target="_blank" href="https://facebook.com/"><i class="fab fa-facebook-f"></i></a>
                                    <a target="_blank" href="https://twitter.com/"><i class="fab fa-twitter"></i></a>
                                    <a target="_blank" href="https://instagram.com/"><i class="fab fa-instagram"></i></a>
                                    <a target="_blank" href="https://pinterest.com/"><i class="fab fa-pinterest-p"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 col-xl-auto">
                        <div class="widget widget_nav_menu  footer-widget">
                            <h3 class="widget_title">Quick link</h3>
                            <div class="menu-all-pages-container">
                                <ul class="menu">
                                    <li><a href="about.html">About Us</a></li>
                                    <li><a href="booking.html">Book Ride</a></li>
                                    <li><a href="service.html">Client Feedback</a></li>
                                    <li><a href="service.html">Our Services</a></li>
                                    <li><a href="team.html">Our Drivers</a></li>
                                    <li><a href="contact.html">Contact Us</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 col-xl-auto">
                        <div class="widget footer-widget">
                            <h3 class="widget_title">Recent Posts</h3>
                            <div class="recent-post-wrap">
                                <div class="recent-post">
                                    <div class="media-img">
                                        <a href="blog-details.html"><img src="assets/img/blog/recent-post-1-2.jpg" alt="Blog Image"></a>
                                    </div>
                                    <div class="media-body">
                                        <div class="recent-post-meta">
                                            <a href="blog.html"><i class="far fa-calendar-days"></i>22th May, 2024</a>
                                        </div>
                                        <h4 class="post-title"><a class="text-inherit" href="blog-details.html">How To Start Car Engine Faster</a></h4>
                                        <a class="line-btn" href="blog.html">Read More<i class="fa-regular fa-arrow-right"></i></a>
                                    </div>
                                </div>
                                <div class="recent-post">
                                    <div class="media-img">
                                        <a href="blog-details.html"><img src="assets/img/blog/recent-post-1-3.jpg" alt="Blog Image"></a>
                                    </div>
                                    <div class="media-body">
                                        <div class="recent-post-meta">
                                            <a href="blog.html"><i class="far fa-calendar-days"></i>25th May, 2024</a>
                                        </div>
                                        <h4 class="post-title"><a class="text-inherit" href="blog-details.html">How to start car engine slowly</a></h4>
                                        <a class="line-btn" href="blog.html">Read More<i class="fa-regular fa-arrow-right"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 col-xl-3">
                        <div class="widget footer-widget">
                            <h3 class="widget_title">Contact Details</h3>
                            <div class="th-widget-about">
                                <h4 class="footer-info-title">Phone Number</h4>
                                <p class="footer-info"><i class="fa-sharp fa-solid fa-phone"></i><a class="text-inherit" href="tel:+468254762443">+468 254 762 443</a></p>
                                <h4 class="footer-info-title">Email Address</h4>
                                <p class="footer-info"><i class="fas fa-envelope"></i><a class="text-inherit" href="mailto:info@email.com">info@Taxiar.com</a></p>
                                <h4 class="footer-info-title">Office Location</h4>
                                <p class="footer-info"><i class="fas fa-map-marker-alt"></i>25 Street, 145 City Road New Town DD14, USA</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="copyright-wrap">
            <div class="container">
                <p class="copyright-text">© 2024 <a href="https://themeforest.net/user/themeholy">Taxiar</a>. All Rights Reserved.</p>
            </div>
        </div>
    </footer>